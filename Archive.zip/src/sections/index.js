export { default as MintSection } from "./mintsection";
export { default as StorySection } from "./story";
export { default as SliderSection } from "./slider";
export { default as RaritySection } from "./rarity";
export { default as Milestone } from "./milestone";
export { default as FeatureSection } from "./features";
export { default as TeamSection } from "./team";
export { default as FaqSection } from "./faq";
