import React from "react";
import Img1 from "../../assets/img/slider-img1.jpg";
import Img2 from "../../assets/img/slider-img2.jpg";
import Img3 from "../../assets/img/slider-img3.jpg";
import Img4 from "../../assets/img/slider-img4.jpg";
import Img5 from "../../assets/img/slider-img5.jpg";
import Img6 from "../../assets/img/slider-img6.gif";
import Img7 from "../../assets/img/slider-img7.jpg";
import Img8 from "../../assets/img/slider-img8.jpg";
import Img9 from "../../assets/img/slider-img9.jpg";
import Img10 from "../../assets/img/slider-img10.jpg";
import Img11 from "../../assets/img/slider-img11.jpg";
import Img12 from "../../assets/img/slider-img12.jpg";
import Img13 from "../../assets/img/slider-img13.gif";
import Img14 from "../../assets/img/slider-img14.jpg";
import Img15 from "../../assets/img/slider-img15.gif";
import Img16 from "../../assets/img/slider-img16.jpg";
import Img17 from "../../assets/img/slider-img17.jpg";
import Img18 from "../../assets/img/slider-img18.jpg";
import Img19 from "../../assets/img/slider-img19.jpg";
import Img20 from "../../assets/img/slider-img20.jpg";
import Img21 from "../../assets/img/slider-img21.gif";
import Img22 from "../../assets/img/slider-img22.gif";
import Img23 from "../../assets/img/slider-img23.jpg";
import Img24 from "../../assets/img/slider-img24.jpg";
import Img25 from "../../assets/img/slider-img25.jpg";
import Img26 from "../../assets/img/slider-img26.jpg";
import Img27 from "../../assets/img/slider-img27.jpg";
import Img28 from "../../assets/img/slider-img28.gif";
import Img29 from "../../assets/img/slider-img29.jpg";
import Img30 from "../../assets/img/slider-img30.jpg";
const Index = () => {
  return (
    <section className="slider-part bg-dark py-3">
      <div className="marquee-wrapper">
        <div className="container">
          <div className="marquee-block">
            <div className="marquee-inner to-left">
              <span>
                <div className="marquee-item">
                  <img src={Img1} alt="img1" />
                </div>
                <div className="marquee-item">
                  <img src={Img2} alt="img2" />
                </div>
                <div className="marquee-item">
                  <img src={Img3} alt="img3" />
                </div>
                <div className="marquee-item">
                  <img src={Img4} alt="img4" />
                </div>
                <div className="marquee-item">
                  <img src={Img5} alt="img5" />
                </div>
                <div className="marquee-item">
                  <img src={Img6} alt="img6" />
                </div>
                <div className="marquee-item">
                  <img src={Img7} alt="img7" />
                </div>
                <div className="marquee-item">
                  <img src={Img8} alt="img8" />
                </div>
                <div className="marquee-item">
                  <img src={Img9} alt="img9" />
                </div>
                <div className="marquee-item">
                  <img src={Img10} alt="img10" />
                </div>
                <div className="marquee-item">
                  <img src={Img11} alt="img11" />
                </div>
                <div className="marquee-item">
                  <img src={Img12} alt="img12" />
                </div>
                <div className="marquee-item">
                  <img src={Img13} alt="img13" />
                </div>
                <div className="marquee-item">
                  <img src={Img14} alt="img14" />
                </div>
                <div className="marquee-item">
                  <img src={Img15} alt="img15" />
                </div>
              </span>
              <span>
                <div className="marquee-item">
                  <img src={Img1} alt="img1" />
                </div>
                <div className="marquee-item">
                  <img src={Img2} alt="img2" />
                </div>
                <div className="marquee-item">
                  <img src={Img3} alt="img3" />
                </div>
                <div className="marquee-item">
                  <img src={Img4} alt="img4" />
                </div>
                <div className="marquee-item">
                  <img src={Img5} alt="img5" />
                </div>
                <div className="marquee-item">
                  <img src={Img6} alt="img6" />
                </div>
                <div className="marquee-item">
                  <img src={Img7} alt="img7" />
                </div>
                <div className="marquee-item">
                  <img src={Img8} alt="img8" />
                </div>
                <div className="marquee-item">
                  <img src={Img9} alt="img9" />
                </div>
                <div className="marquee-item">
                  <img src={Img10} alt="img10" />
                </div>
                <div className="marquee-item">
                  <img src={Img11} alt="img11" />
                </div>
                <div className="marquee-item">
                  <img src={Img12} alt="img12" />
                </div>
                <div className="marquee-item">
                  <img src={Img13} alt="img13" />
                </div>
                <div className="marquee-item">
                  <img src={Img14} alt="img14" />
                </div>
                <div className="marquee-item">
                  <img src={Img15} alt="img15" />
                </div>
              </span>
            </div>
          </div>
          <div className="marquee-block">
            <div className="marquee-inner to-right">
              <span>
                <div className="marquee-item">
                  <img src={Img16} alt="img16" />
                </div>
                <div className="marquee-item">
                  <img src={Img17} alt="img17" />
                </div>
                <div className="marquee-item">
                  <img src={Img18} alt="img18" />
                </div>
                <div className="marquee-item">
                  <img src={Img19} alt="img19" />
                </div>
                <div className="marquee-item">
                  <img src={Img20} alt="img20" />
                </div>
                <div className="marquee-item">
                  <img src={Img21} alt="img21" />
                </div>
                <div className="marquee-item">
                  <img src={Img22} alt="img22" />
                </div>
                <div className="marquee-item">
                  <img src={Img23} alt="img22" />
                </div>
                <div className="marquee-item">
                  <img src={Img24} alt="img24" />
                </div>
                <div className="marquee-item">
                  <img src={Img25} alt="img25" />
                </div>
                <div className="marquee-item">
                  <img src={Img26} alt="img26" />
                </div>
                <div className="marquee-item">
                  <img src={Img27} alt="img27" />
                </div>
                <div className="marquee-item">
                  <img src={Img28} alt="img28" />
                </div>
                <div className="marquee-item">
                  <img src={Img29} alt="img29" />
                </div>
                <div className="marquee-item">
                  <img src={Img30} alt="img30" />
                </div>
              </span>
              <span>
                <div className="marquee-item">
                  <img src={Img16} alt="img16" />
                </div>
                <div className="marquee-item">
                  <img src={Img17} alt="img17" />
                </div>
                <div className="marquee-item">
                  <img src={Img18} alt="img18" />
                </div>
                <div className="marquee-item">
                  <img src={Img19} alt="img19" />
                </div>
                <div className="marquee-item">
                  <img src={Img20} alt="img20" />
                </div>
                <div className="marquee-item">
                  <img src={Img21} alt="img21" />
                </div>
                <div className="marquee-item">
                  <img src={Img22} alt="img22" />
                </div>
                <div className="marquee-item">
                  <img src={Img23} alt="img22" />
                </div>
                <div className="marquee-item">
                  <img src={Img24} alt="img24" />
                </div>
                <div className="marquee-item">
                  <img src={Img25} alt="img25" />
                </div>
                <div className="marquee-item">
                  <img src={Img26} alt="img26" />
                </div>
                <div className="marquee-item">
                  <img src={Img27} alt="img27" />
                </div>
                <div className="marquee-item">
                  <img src={Img28} alt="img28" />
                </div>
                <div className="marquee-item">
                  <img src={Img29} alt="img29" />
                </div>
                <div className="marquee-item">
                  <img src={Img30} alt="img30" />
                </div>
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Index;
